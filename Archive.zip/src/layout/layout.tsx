import * as React from 'react'
import { connect } from 'react-redux'

export interface LayoutProps {}

/* Responsive main layout of app. */
export class Layout extends React.Component<LayoutProps, any> {
  public render() {
    return <div>In development</div>
  }
}
