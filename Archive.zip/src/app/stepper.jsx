import React, { Component } from "react";
import Progress from "./progress";
import Steps from "./steps";
import Step from "./step";
import Stage from "./stage";

export const StepperContext = React.createContext();
export default class Stepper extends Component {
  static Progress = Progress;
  static Steps = Steps;
  static Step = Step;
  static Stage = Stage;
  state = {
    stage: this.props.stage
  };
  static defaultProps = {
    stage: 1
  };

  render() {
    const { stage } = this.state;

    return (
      <StepperContext.Provider
        value={{
          stage: this.state.stage,
          handleClick: () =>
            this.setState({
              stage: this.state.stage + 1
            })
        }}
      />
    );
  }
}
