import React, { Component } from "react";
import { Transition, TransitionGroup } from "react-transition-group";

export default class Steps extends Component {
  render() {
    const { stage, handleClick } = this.props;
    console.log("props: " + this.props);
    return (
      <div>
        <div>
          {[...this.props.children].map(child => (
            <div>{child.props.num === stage && child}</div>
          ))}
        </div>
        <div>
          <button
            onClick={handleClick}
            disabled={stage === this.props.children.length}
          >
            Continue
          </button>
        </div>
      </div>
    );
  }
}
