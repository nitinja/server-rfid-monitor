import React, { Component } from "react";
import { EditorFormValues } from "../editor/editor";
import Stepper from "./stepper";

/* Main App */
class App extends Component {
  dummySubmit = async (values: EditorFormValues) => {
    console.log(values);
    return null;
  };

  public render() {
    return (
      <div>
        <h1>RFID Enabled Server Monitor</h1>
        <h2>Sample form to test Formik and ant-ui</h2>
        {/* <Editor submit={this.dummySubmit} /> */}
        <Stepper stage={1}>
          <Stepper.Progress>
            <Stepper.Stage num={1} />
            <Stepper.Stage num={2} />
            <Stepper.Stage num={3} />
            <Stepper.Stage num={4} />
            <Stepper.Stage num={5} />
            <Stepper.Stage num={6} />
          </Stepper.Progress>
          <Stepper.Steps>
            <Stepper.Step num={1} text={"Stage 1"} />
            <Stepper.Step num={2} text={"Stage 2"} />
            <Stepper.Step num={3} text={"Stage 3"} />
            <Stepper.Step num={4} text={"Stage 4"} />
            <Stepper.Step num={5} text={"Stage 5"} />
            <Stepper.Step num={6} text={"Complete"} />
          </Stepper.Steps>
        </Stepper>
      </div>
    );
  }
}

export default App;
