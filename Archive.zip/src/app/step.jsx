import React, { Component } from "react";
import { Transition, TransitionGroup } from "react-transition-group";

export default class Step extends Component {
  render() {
    return <div>{this.props.text}</div>;
  }
}
