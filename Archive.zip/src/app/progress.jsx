import React, { Component } from "react";

export default class Progress extends Component {
  render() {
    const stage = this.props.stage;
    const children = React.Children.map(this.props.children, child =>
      React.cloneElement(child, { stage, handleClick: this.props.handleClick })
    );
    return <div>{children}</div>;
  }
}
